//
//  ChangeCarCollectionViewCell.swift
//  SolievGame
//
//  Created by user on 11.11.2021.
//

import UIKit

class ChangeCarCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var carPicture: UIImageView!
}
